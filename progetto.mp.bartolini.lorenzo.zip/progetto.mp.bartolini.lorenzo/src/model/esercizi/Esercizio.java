package model.esercizi;

public interface Esercizio {
	
	public String getNomeEsercizio();
	
	public double getCostoPerRipetizione();
	
	public double getCostoAlMinuto();
	
}
