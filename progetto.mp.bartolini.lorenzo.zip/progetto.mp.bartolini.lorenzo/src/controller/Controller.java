package controller;

public interface Controller { 
	
	public void notifyClientePostazioneLibera(String codicePostazione, String codiceCliente);
	
}
